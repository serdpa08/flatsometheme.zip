<?php

return array(
    'type' => 'textfield',
    'heading' => 'Video MP4',
    'description' => 'Nice tool to convert videos: https://cloudconvert.org/',
);
