<?php

/**
 * Get path to a file relative to plugin directory.
 *
 * @param  string $path
 * @return string
 */
function ux_builder_path( $path = '' ) {
  return UX_BUILDER_PATH . $path;
}
