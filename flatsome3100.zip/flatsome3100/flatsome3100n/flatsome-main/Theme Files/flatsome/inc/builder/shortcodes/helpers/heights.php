<?php

return array(
	array('title' => 'Auto','value' => ''),
	array('title' => 'Full','value' => '100%'),
	array('title' => '16:9','value' => '56.25%'),
	array('title' => '1:2','value' => '50%'),
	array('title' => '1:1','value' => '99.99%'),
);
